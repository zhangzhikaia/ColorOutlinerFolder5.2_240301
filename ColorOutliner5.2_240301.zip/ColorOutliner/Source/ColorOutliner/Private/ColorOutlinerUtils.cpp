// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "ColorOutlinerUtils.h"

#include "Containers/Map.h"

namespace SceneOutlinerFolderUtils
{
	static TMap< FString, FLinearColor > SceneOutlinerPathColors;

	static TMap< FString, FLinearColor > TempPathColors;

	static TMap< UWorld*, FString > MapsOldName;

	static TArray<FString> MapPathsGoingDelete;

	static bool IsTempMap;

	static FString MapPath;

	static bool IsFolderMoved;
}

FLinearColor SceneOutlinerFolderUtils::GetOutlinerFolderDefaultColor()
{
	static const FName OutlinerFolderColorName("SceneOutliner.FolderClosed");
	return FAppStyle::Get().GetBrush(OutlinerFolderColorName)->TintColor.GetSpecifiedColor();
}

FName SceneOutlinerFolderUtils::GetDefaultContextBaseMenuName()
{
	static const FName DefaultContextBaseMenuName("SceneOutliner.DefaultContextMenuBase");
	static const FName DefaultContextMenuName("SceneOutliner.DefaultContextMenu");
	return DefaultContextBaseMenuName;
}

const FString SceneOutlinerFolderUtils::GetFolderFullPath(const FActorFolderTreeItem* SelectedFolder)
{
	return OLGetMapPath().Append(TEXT("/")+SelectedFolder->GetPath().ToString());
}

const FString SceneOutlinerFolderUtils::GetFolderFullPath(const FFolder& Folder)
{
	return OLGetMapPath().Append(TEXT("/")+Folder.GetPath().ToString());
}

TOptional<FLinearColor> SceneOutlinerFolderUtils::GetFolderColor(const FString& FolderPath)
{
	auto GetPathColorInternal = [](const FString& InPath) -> TOptional<FLinearColor>
	{
		// See if we have a value cached first
		FLinearColor* CachedColor = SceneOutlinerPathColors.Find(InPath);
		if(CachedColor)
		{
			return *CachedColor;
		}
		
		// Loads the color of folder at the given path from the config
		if(FPaths::FileExists(GEditorPerProjectIni))
		{
			// Create a new entry from the config, skip if it's default
			FString ColorStr;
			if(GConfig->GetString(TEXT("OutlinerFolderColor"), *InPath, ColorStr, GEditorPerProjectIni))
			{
				FLinearColor Color;
				if(Color.InitFromString(ColorStr) && !Color.Equals(SceneOutlinerFolderUtils::GetOutlinerFolderDefaultColor()))
				{
					return SceneOutlinerPathColors.Add(InPath, FLinearColor(Color));
				}
			}
			else
			{
				return SceneOutlinerPathColors.Add(InPath, FLinearColor(SceneOutlinerFolderUtils::GetOutlinerFolderDefaultColor()));
			}
		}

		return TOptional<FLinearColor>();
	};

	// First try and find the color using the given path, as this works correctly for both assets and classes
	TOptional<FLinearColor> FoundColor = GetPathColorInternal(FolderPath);
	if(FoundColor.IsSet())
	{
		return FoundColor;
	}

	// If that failed, try and use the filename (assets used to use this as their color key, but it doesn't work with classes)
	{
		FString RelativePath;
		if (FPackageName::TryConvertLongPackageNameToFilename(FolderPath / FString(), RelativePath))
		{
			return GetPathColorInternal(RelativePath);
		}
	}

	return TOptional<FLinearColor>();
}

void SceneOutlinerFolderUtils::SaveFolderColors(const FString& FolderPath, TOptional<FLinearColor> FolderColor)
{
	auto SetPathColorInternal = [](const FString& InPath, FLinearColor InFolderColor)
	{
		// Saves the color of the folder to the config
		if(FPaths::FileExists(GEditorPerProjectIni))
		{
			GConfig->SetString(TEXT("OutlinerFolderColor"), *InPath, *InFolderColor.ToString(), GEditorPerProjectIni);
		}

		// Update the map too
		SceneOutlinerPathColors.Add(InPath, InFolderColor);
	};

	auto RemoveColorInternal = [](const FString& InPath)
	{
		// Remove the color of the folder from the config
		if(FPaths::FileExists(GEditorPerProjectIni))
		{
			GConfig->RemoveKey(TEXT("OutlinerFolderColor"), *InPath, GEditorPerProjectIni);
		}

		// Update the map too
		SceneOutlinerPathColors.Remove(InPath);
	};

	// Remove the color if it's invalid or default
	const bool bRemove = !FolderColor.IsSet() || FolderColor->Equals(SceneOutlinerFolderUtils::GetOutlinerFolderDefaultColor());
	if(bRemove)
	{
		RemoveColorInternal(FolderPath);
	}
	else
	{
		SetPathColorInternal(FolderPath, FolderColor.GetValue());
	}

	// Make sure and remove any colors using the legacy path format
	{
		FString RelativePath;
		if (FPackageName::TryConvertLongPackageNameToFilename(FolderPath / FString(), RelativePath))
		{
			return RemoveColorInternal(RelativePath);
		}
	}
}

void SceneOutlinerFolderUtils::SetRowWidgetColor(TSharedPtr<SWidget> RowWidget, const FLinearColor InColor)
{
	TSharedPtr<SWidget> CurrentWidget = RowWidget;
	if(CurrentWidget->GetChildren()->Num()==0) return;
	CurrentWidget = CurrentWidget->GetChildren()->GetChildAt(0);
						
	if(CurrentWidget->GetChildren()->Num()==0) return;
	CurrentWidget = CurrentWidget->GetChildren()->GetChildAt(0);
						
	if(CurrentWidget->GetChildren()->Num()==0) return;
	/*Folder_SImage*/
	CurrentWidget = CurrentWidget->GetChildren()->GetChildAt(0);
	if(TSharedPtr<SImage> Image = StaticCastSharedPtr<SImage>(CurrentWidget))
	{
		Image->SetColorAndOpacity(InColor*1.5);
	}
}

TOptional<FLinearColor> SceneOutlinerFolderUtils::GetFolderColorTemp(const FString& FolderPath)
{
	auto GetPathColorInternal = [](const FString& InPath) -> TOptional<FLinearColor>
	{
		// See if we have a value cached first
		FLinearColor* CachedColor = TempPathColors.Find(InPath);
		if(CachedColor)
		{
			return *CachedColor;
		}
		
		return TOptional<FLinearColor>();
	};
	// First try and find the color using the given path, as this works correctly for both assets and classes
	TOptional<FLinearColor> FoundColor = GetPathColorInternal(FolderPath);
	if(FoundColor.IsSet())
	{
		return FoundColor;
	}
	return TOptional<FLinearColor>();
}

void SceneOutlinerFolderUtils::SaveFolderColorsTemp(const FString& FolderPath, TOptional<FLinearColor> FolderColor)
{
	// Remove the color if it's invalid or default
	const bool bRemove = !FolderColor.IsSet() || FolderColor->Equals(SceneOutlinerFolderUtils::GetOutlinerFolderDefaultColor());
	if(bRemove)
	{
		TempPathColors.Remove(FolderPath);
	}
	else
	{
		TempPathColors.Add(FolderPath, FolderColor.GetValue());
	}
}

void SceneOutlinerFolderUtils::ClearFolderColorsTemp(){ TempPathColors.Empty();}

void SceneOutlinerFolderUtils::TempToSave(const UWorld* World)
{
	FString PrefixPath = World->GetPathName();
	PrefixPath.RemoveFromEnd(TEXT(".")+World->GetMapName());

	for(const TTuple<FString, FLinearColor>& pair : TempPathColors)
	{
		FString FullPath = PrefixPath;
		FullPath.Append(TEXT("/")+pair.Key);
		SaveFolderColors(FullPath,pair.Value);
	}
}

void SceneOutlinerFolderUtils::SaveMapOldName(UWorld* World)
{
	FString PrefixPath = World->GetPathName();
	PrefixPath.RemoveFromEnd(TEXT(".")+World->GetMapName());

	MapsOldName.Add(World, PrefixPath);
}

void SceneOutlinerFolderUtils::OnWorldPathPostChanged(UWorld* World)
{
	FString OldName;
	MapsOldName.RemoveAndCopyValue(World,OldName);

	FString NewName = World->GetPathName();
	NewName.RemoveFromEnd(TEXT(".")+World->GetMapName());
	
	for(TTuple<FString, FLinearColor>& pair: SceneOutlinerPathColors)
	{
		if(pair.Key.StartsWith(OldName,ESearchCase::CaseSensitive))
		{
			FString OldFullPath = pair.Key;
			
			pair.Key.RemoveFromStart(OldName,ESearchCase::CaseSensitive);
			pair.Key = NewName + pair.Key;
			
			if(FPaths::FileExists(GEditorPerProjectIni))
			{
				FString Color;
				GConfig->GetValue(TEXT("OutlinerFolderColor"), *OldFullPath, Color, GEditorPerProjectIni);
				GConfig->RemoveKey(TEXT("OutlinerFolderColor"), *OldFullPath, GEditorPerProjectIni);
				GConfig->SetString(TEXT("OutlinerFolderColor"), *pair.Key, *Color, GEditorPerProjectIni);
			}
		}
	}
}

void SceneOutlinerFolderUtils::SavePathPreDelete(const TArray<UObject*>& Objects)
{
	MapPathsGoingDelete.Empty();
	
	for(const UObject* Object : Objects)
	{
		if(Cast<UWorld>(Object))
		{
			FString PrefixPath = Object->GetPathName();
			PrefixPath.RemoveFromEnd(TEXT(".")+Object->GetName());
			
			MapPathsGoingDelete.Add(PrefixPath);
		}
	}
}

void SceneOutlinerFolderUtils::OnWorldDeleted()
{
	for(const FString Path : MapPathsGoingDelete)
	{
		for(const TTuple<FString, FLinearColor>& pair: SceneOutlinerPathColors)
		{
			if(pair.Key.StartsWith(Path,ESearchCase::CaseSensitive))
			{
				if(FPaths::FileExists(GEditorPerProjectIni))
				{
					GConfig->RemoveKey(TEXT("OutlinerFolderColor"), *pair.Key, GEditorPerProjectIni);
				}
				SceneOutlinerPathColors.Remove(pair.Key);
			}
		}
	}
}

void SceneOutlinerFolderUtils::UpdateFullPath(const FFolder& Source, const FFolder& Dest)
{
	FLinearColor SColor;
	const FString SourcePath = GetFolderFullPath(Source);
	const FString DestPath = GetFolderFullPath(Dest);

	if(SceneOutlinerPathColors.Contains(SourcePath))
	{
		SceneOutlinerPathColors.RemoveAndCopyValue(SourcePath,SColor);
		SceneOutlinerPathColors.Add(DestPath,SColor);
	}
	
	if(FPaths::FileExists(GEditorPerProjectIni))
	{
		FString FColor;
		if(GConfig->GetString(TEXT("OutlinerFolderColor"), *SourcePath, FColor, GEditorPerProjectIni))
		{
			GConfig->RemoveKey(TEXT("OutlinerFolderColor"), *SourcePath, GEditorPerProjectIni);
			GConfig->SetString(TEXT("OutlinerFolderColor"), *DestPath, *FColor, GEditorPerProjectIni);
		}
	}
}

void SceneOutlinerFolderUtils::DeleteFullPath(const FFolder& Folder)
{
	const FString FolderPath = GetFolderFullPath(Folder);
	
	if(SceneOutlinerPathColors.Contains(FolderPath))
	{
		SceneOutlinerPathColors.Remove(FolderPath);
	}
	
	if(FPaths::FileExists(GEditorPerProjectIni))
	{
		FString FColor;
		if(GConfig->GetString(TEXT("OutlinerFolderColor"), *FolderPath, FColor, GEditorPerProjectIni))
		{
			GConfig->RemoveKey(TEXT("OutlinerFolderColor"), *FolderPath, GEditorPerProjectIni);
		}
	}
}

void SceneOutlinerFolderUtils::UpdateFullPathTemp(const FFolder& Source, const FFolder& Dest)
{
	FLinearColor SColor;
	const FString SourcePath = Source.GetPath().ToString();
	const FString DestPath = Dest.GetPath().ToString();

	if(TempPathColors.Contains(SourcePath))
	{
		TempPathColors.RemoveAndCopyValue(SourcePath,SColor);
		TempPathColors.Add(DestPath,SColor);
	}
}

void SceneOutlinerFolderUtils::DeleteFullPathTemp(const FFolder& Folder)
{
	const FString FolderPath = Folder.GetPath().ToString();
	
	if(TempPathColors.Contains(FolderPath))
	{
		TempPathColors.Remove(FolderPath);
	}
}

void SceneOutlinerFolderUtils::SetIsTempMap(const bool IsTemp){ IsTempMap = IsTemp;}

const bool SceneOutlinerFolderUtils::GetIsTempMap(){ return IsTempMap;}

void SceneOutlinerFolderUtils::OLSetMapPath(const FString InMapPath){ MapPath = InMapPath;}

FString SceneOutlinerFolderUtils::OLGetMapPath(){ return MapPath;}

void SceneOutlinerFolderUtils::SetIsFolderMoved(const bool IsMoved){ IsFolderMoved = IsMoved;}

const bool SceneOutlinerFolderUtils::GetIsFolderMoved(){ return IsFolderMoved;}
