// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once
#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "SceneOutlinerFwd.h"

class SSceneOutlinerTreeRow;

class FColorOutlinerModule : public IModuleInterface
{
public:
	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:
	struct HackSMultiColumnTableRow : SMultiColumnTableRow<FSceneOutlinerTreeItemPtr>
	{
		const TSharedRef<SWidget>* HackGetWidgetFromColumnId(const FName& ColumnId){return GetWidgetFromColumnId(ColumnId);}
	};

private:
	void RegisterOnMapRename();

	void RegisterOnMapDeleted();
	
	void RegisterOnMapChanged();
    	
	void RegisterOnFolderOperate();
	
	void RegisterOutlinerItemLabelColumn();

	void RegisterOutlinerContextMenuExtend();

	void OutlinerExecutePickColor();

	void OnLinearColorValueChanged(const FLinearColor InColor);

	FReply OnColorClicked(const FLinearColor InColor);
	
	void SetRowItemColor(TSharedPtr<SSceneOutlinerTreeRow> InRow,const FLinearColor InColor);

private:
	TWeakPtr<SSceneOutliner> SelectedSceneOutliner;
	
	TArray<FSceneOutlinerTreeItemPtr> ExecuteFolderItems;
	
private:
	FDelegateHandle OnPreWorldRenameHandle;
	FDelegateHandle OnPostWorldRenameHandle;
	
	FDelegateHandle OnAssetsPreDeleteHandle;
	FDelegateHandle OnAssetsDeletedHandle;
	
	FDelegateHandle OnMapChangedHandle;
	
	FDelegateHandle OnFolderMovedHandle;
	FDelegateHandle OnFolderDeletedHandle;
};
